<?php

class Education_model extends CIF_model
{
    public $_table = 'education';
    public $_primary_keys = array('education_id');


}
