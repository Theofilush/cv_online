<?php

class About_model extends CIF_model
{
    public $_table = 'about';
    public $_primary_keys = array('key');


}
