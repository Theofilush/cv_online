<?php

class Projects_categories_model extends CIF_model
{
    public $_table = 'projects_categories';
    public $_primary_keys = array('project_category_id');


}
