<?php

class Skills_categories_model extends CIF_model
{
    public $_table = 'skills_categories';
    public $_primary_keys = array('skill_category_id');


}
