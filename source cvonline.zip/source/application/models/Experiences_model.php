<?php

class Experiences_model extends CIF_model
{
    public $_table = 'experiences';
    public $_primary_keys = array('experience_id');


}
