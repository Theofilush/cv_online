<?php

$config['protocol'] = 'smtp';
$config['useragent'] = '';

$config['smtp_host'] = '';
$config['smtp_user'] = '';
$config['smtp_pass'] = '';
$config['smtp_port'] = '25';

$config['smtp_timeout'] = '30';
$config['mailtype'] = 'html';
$config['priority'] = '1';
$config['charset'] = 'utf-8';
